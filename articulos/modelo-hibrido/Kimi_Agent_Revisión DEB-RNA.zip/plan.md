# Plan: Revisión y Desarrollo Completo del Artículo DEB-RNA

## Objetivo
Revisar científicamente, completar y desarrollar el artículo académico LaTeX sobre el modelo híbrido DEB-RNA para estimación de biomasa en *Hermetia illucens*, generando un PDF final de alta calidad.

## Etapas

### Stage 1 — Análisis y Revisión Científica
- Revisar la consistencia matemática del modelo DEB simplificado
- Verificar ecuaciones diferenciales, parámetros y referencias bibliográficas
- Revisar la arquitectura RNA-B y su justificación teórica
- Verificar la coherencia de la integración híbrida
- Identificar secciones incompletas o que necesitan desarrollo

### Stage 2 — Desarrollo y Escritura Completa
- Cargar skill `paper-writing`
- Desarrollar secciones incompletas (Discusión, Conclusiones, etc.)
- Ampliar marco teórico con más profundidad
- Completar el protocolo de validación con más detalle
- Revisar y mejorar el idioma y estilo académico

### Stage 3 — Compilación y Producción del PDF
- Cargar skill `pdf`
- Generar el documento PDF profesional desde LaTeX
- Verificar renderizado de ecuaciones, tablas, algoritmos y diagrama TikZ
- Entregar archivo PDF final

## Skills Requeridos
- `paper-writing`: Para revisión académica y desarrollo del contenido
- `pdf`: Para compilación del LaTeX a PDF profesional

## Archivos
- Entrada: `/mnt/agents/output/estructura_hibrida_deb_rna.tex`
- Salida: `/mnt/agents/output/estructura_hibrida_deb_rna.pdf`
