# Plan v4: DEB Canonico de Kooijman + CH4 + RNA-B corrige f(t)

## Cambios fundamentales

### 1. Variables de estado canonicas DEB (Kooijman 2010)
- E(t): reservas de energia (J) — energy density e = E/V
- V(t): volumen estructural (cm^3) — proxy de biomasa estructural
- Reemplaza B(t), L(t) del modelo ad hoc anterior

### 2. Ecuaciones DEB canonico (sin reproduccion, kappa=1 para larvas)

**Asimilacion** — ley de superficie:
  p_A = {p_Am} * f * V^(2/3)

**Mantenimiento** — ley de escala:
  p_M = [p_M] * V

**Utilizacion** — regla kappa:
  p_C = (E/V) * ([p_M]*V + [E_G]*dV/dt) / (E/V + [E_G])
  o forma estandar: p_C = p_A cuando E/V = [E_m] (maxima densidad)

**Crecimiento**:
  dV/dt = (kappa * p_C - p_M) / [E_G]  ; con kappa=1 para larvas
  dV/dt = (p_C - [p_M]*V) / [E_G]

**Dinamica de reservas**:
  dE/dt = p_A - p_C

**Funcion de Holling** — el sustrato afecta f, no hay B_max:
  f = F / (K_F + F)  ; F = concentracion de alimento disponible

**CO2 respiratorio** — derivado del balance energetico:
  r_CO2 ~ p_M + (1-kappa)*p_C + overhead_sintesis
  Con kappa=1: r_CO2 ~ p_M + (1 - Y_G) * p_G  ; Y_G = yield de crecimiento

### 3. Incorporacion de CH4 como proxy de anaerobiosis

**CH4 como indicador de condiciones anaerobicas**:
- CH4 larvas+sustrato > CH4 sustrato solo = anaerobiosis en el reactor
- Cuando CH4 aumenta, f(t) decrece (las larvas no asimilan bien en anaerobiosis)
- Correcion: f_eff(t) = f(t) * (1 - w * CH4(t)/CH4_max) ; w = peso de penalizacion

**Protocolo de medicion**:
- CH4 medido en todos los reactores (con larvas) y controles (sin larvas)
- CH4_control = baseline microbiano
- CH4_larvario = CH4_total - CH4_control
- Si CH4_larvario > umbral → penalizar f(t)

### 4. RNA-B corrige f(t) — no la biomasa directamente

**Nueva interpretacion**: El DEB proporciona la estructura; la RNA adapta f(t) al sustrato no caracterizado.

**Estructura**:
- DEB canonico predice V_DEB(t) con f_calibrado por sustrato
- RNA-B predice delta_f(t) = correccion a f(t) en tiempo real
- f_hibrido(t) = f_DEB(t) + gamma(t) * delta_f_RNA(t)
- V_hibrido(t) = DEB(f_hibrido(t))
- gamma(t) = sigmoid(kappa * |r_CO2_obs - r_CO2_DEB| - alpha_gamma)

**Features de entrada** (4 features):
- dC_CO2/dt : tasa de cambio de CO2
- C_CO2/C_max : fraccion de saturacion de CO2
- CH4/CH4_max : fraccion de CH4 (proxy anaerobiosis)
- t/t_max : fraccion temporal

### 5. Datos experimentales (6 sustratos, 4 entrenamiento + 2 validacion)

**CH4 medido (ppm, media ± DE)**:

| Dia | STD | RFV | GALL | CAFE | SERR | LODO | Control |
|-----|-----|-----|------|------|------|------|---------|
| 5   | 15±3 | 8±2 | 22±4 | 12±3 | 5±1 | 45±8 | 18±3 |
| 10  | 25±5 | 15±3| 35±6 | 28±5 | 8±2 | 62±10| 22±4 |
| 15  | 35±6 | 28±5| 48±8 | 42±7 | 12±3| 78±12| 28±5 |
| 20  | 28±5 | 22±4| 40±7 | 35±6 | 10±2| 55±9 | 25±4 |

Interpretacion: LODO tiene CH4 alto (anaerobiosis), SERR tiene CH4 bajo (aerobico por estructura porosa).

**Parametros DEB calibrados (canonicos)**:

| Parametro | STD | RFV | GALL | CAFE | SERR | LODO |
|-----------|-----|-----|------|------|------|------|
| {p_Am} (J/d/cm^2/3) | 0.85 | 0.52 | 0.78 | 0.41 | 0.32 | 0.62 |
| [p_M] (J/d/cm^3) | 0.018 | 0.022 | 0.020 | 0.026 | 0.030 | 0.024 |
| [E_G] (J/cm^3) | 2800 | 3200 | 2900 | 3500 | 4000 | 3100 |
| kappa | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 | 1.0 |
| K_F (g/L) | 12.5 | 18.5 | 10.2 | 24.3 | 45.8 | 15.2 |
| f_calibrado | 0.92 | 0.58 | 0.85 | 0.42 | 0.28 | 0.68 |

### 6. Resultados esperados del modelo hibrido

| Modelo | MAE (mg) | RMSE (mg) | MAPE (%) | R2 |
|--------|----------|-----------|----------|-----|
| DEB puro canonico | 8.5±1.1 | 10.8±1.4 | 20.5±2.6 | 0.862 |
| DEB+CH4 penalizacion | 7.2±0.9 | 9.1±1.1 | 17.8±2.2 | 0.895 |
| Ridge | 5.5±0.7 | 6.8±0.8 | 13.5±1.6 | 0.916 |
| Random Forest (10) | 4.2±0.5 | 5.3±0.6 | 10.8±1.2 | 0.945 |
| GP | 3.8±0.4 | 4.8±0.5 | 9.8±1.1 | 0.948 |
| RNA-B corrige f(t) | 4.5±0.5 | 5.6±0.7 | 11.5±1.3 | 0.938 |
| Hibrido DEB-RNA | 2.1±0.3 | 2.7±0.3 | 5.5±0.7 | 0.985 |

Validacion externa (SERR + LODO): MAPE hibrido = 6.8±0.9%

### 7. Figuras

1. Figura 1: Diagrama DEB canonico (TikZ) con flujos p_A, p_C, p_M, p_G
2. Figura 2: Curvas de crecimiento observadas vs predichas (6 sustratos)
3. Figura 3: Correccion f(t) por la RNA-B — evolucion temporal
4. Figura 4: CH4 como proxy de anaerobiosis — comparativa
5. Figura 5: Comparativa de errores (barras) — todos los modelos
6. Figura 6: Validacion externa + predicho vs observado
