# Revision Cientifica: Modelo DEB Simplificado para Estimacion de Biomasa en *Hermetia illucens*

**Revisor:** Experto en ecologia fisiologica y modelado energetico DEB  
**Fecha:** Junio 2025  
**Articulo revisado:** "Modelo Hibrido DEB--RNA para la Estimacion de Biomasa en *Hermetia illucens* mediante CO$_2$ Respiratorio"  
**Autor del articulo:** John Jairo Leal Gomez (Universidad Nacional de Colombia, Palmira)  

---

## Resumen Ejecutivo de la Revision

El articulo presenta un modelo hibrido DEB--RNA-B para estimar biomasa larvaria de *Hermetia illucens* (BSF) a partir de CO$_2$ respiratorio. La formulacion se basa principalmente en el modelo dinamico de Eriksen (2022) publicado en *PLoS ONE* y en los datos metabolicos de Laganaro et al. (2021). 

**Veredicto general:** El modelo DEB simplificado constituye una base fisiologica razonable pero presenta **inconsistencias matematicas importantes**, **parametros insuficientemente documentados** y **omisiones conceptuales significativas** que deben resolverse antes de su aplicacion experimental. La integracion con RNA-B es metodologicamente problematica dada la escasez de datos de entrenamiento.

**Puntuacion por criterios (1--10):**

| Criterio | Puntuacion | Severidad |
|----------|-----------|-----------|
| Consistencia matematica | 5/10 | Alta |
| Validez de parametros | 6/10 | Media |
| Coherencia metabolismo--crecimiento | 6/10 | Media |
| Modelo de CO$_2$ | 5/10 | Alta |
| Documentacion y reproducibilidad | 4/10 | Alta |
| Relevancia para bioconversion | 8/10 | Baja |

---

## 1. Consistencia Matematica de las Ecuaciones Diferenciales

### 1.1 Ecuacion (1): dB/dt = mu_B * B

**Formulacion en el articulo:**
```
dB/dt = r_B = mu_B * B                                    (1)
```

**Evaluacion:** Matematicamente consistente si mu_B se interpreta como la **tasa especifica de crecimiento** (dia^-1) de la biomasa estructural B. Esta ecuacion asume forma exponencial cuando mu_B > 0 y constante.

**Hallazgos:**

- **CORRECTO en forma:** La ecuacion es una forma estandar de crecimiento exponencial con tasa variable.
- **INCONSISTENCIA conceptual con DEB estandar:** En la teoria DEB canonica de Kooijman (2010), el crecimiento de la estructura V sigue una ecuacion diferente que incorpora la regla kappa, el mantenimiento somatico y la mobilizacion de reservas. La ecuacion (1) del articulo es una **reduccion empirica** basada en la ecuacion logistica de Verhulst combinada con principios DEB, no una derivacion DEB pura. Esto es aceptable para un modelo simplificado pero debe explicitarse.

- **PROBLEMA de notacion:** El articulo define r_B como "tasa de sintesis de biomasa estructural" y luego establece r_B = mu_B * B. Sin embargo, en la ecuacion (5) de CO2, r_B aparece nuevamente como Y_B * r_B para el costo de sintesis estructural. Esto genera ambiguedad: r_B en (1) es dB/dt, pero en (5) el termino Y_B * r_B usa r_B como si fuera la tasa bruta de asimilacion antes de costos. Esta dualidad de significado para r_B es **matematicamente confusa**.

**Recomendacion:** Definir claramente r_B = dB/dt y usar una notacion distinta para la tasa bruta de sintesis (ej. r_{B,gross}) en la ecuacion de CO2.

---

### 1.2 Ecuacion (3): mu_B con Regulacion Logistica

**Formulacion en el articulo:**
```
mu_B = ((a - m) / (1 + Y_B)) * [1 - (B / B_max)^beta]     (3)
```

**Evaluacion:** Matematicamente consistente pero con **simplificaciones importantes** respecto al modelo original de Eriksen (2022).

**Hallazgos:**

- **CORRECTO:** La estructura combina una tasa maxima de crecimiento neto ((a-m)/(1+Y_B)) con un factor de regulacion logistica generalizada [1 - (B/B_max)^beta]. Esta es la aproximacion de Laganaro et al. (2021) y Eriksen (2022).

- **INCONSISTENCIA con Eriksen (2022):** El modelo original de Eriksen usa **dos funciones logisticas separadas**:
  1. Una que reduce la **asimilacion** con el peso: a = a_max * [1 - (X_DW / X_DWmax)^n1]
  2. Otra que reduce el **crecimiento especifico**: factor [1 - (X_DW / X_DWmax)^n2]
  
  La diferencia entre estas dos funciones es lo que genera el **exceso de asimilados** que se almacenan como lipidos. En el articulo revisado, estas dos funciones se colapsan en una sola ecuacion para mu_B. Esto **elimina el mecanismo central** que permite el modelado de acumulacion lipidica como proceso emergente.

- **PROBLEMA con beta:** El coeficiente beta no tiene valor asignado en el texto principal. En el pseudocodigo (algoritmo) aparece beta = 1.5, pero no se justifica. Eriksen (2022) usa valores similares pero los deriva del ajuste a datos.

- **PROBLEMA de unidades:** Si a es una tasa especifica (dia^-1) y m tambien (dia^-1), entonces (a - m) tiene unidades dia^-1. Al dividir por (1 + Y_B) (adimensional), el resultado tiene unidades dia^-1. El factor logístico es adimensional. Por tanto, mu_B tiene unidades correctas de dia^-1. Las unidades son consistentes.

**Recomendacion:** Considerar separar las dos funciones logisticas (asimilacion y crecimiento) para recuperar el mecanismo de acumulacion lipidica del modelo de Eriksen (2022), o justificar explicitamente por que se colapsan en una sola.

---

### 1.3 Ecuacion (5): Produccion de CO2

**Formulacion en el articulo:**
```
r_CO2 = m * B + Y_B * r_B + Y_L * r_L                      (5)
```

**Evaluacion:** Esta ecuacion tiene una **INCONSISTENCIA GRAVE** entre la formulacion teorica y su implementacion.

**Hallazgos:**

- **CORRECTO en principio:** La descomposicion en tres componentes (mantenimiento, sintesis estructural, sintesis lipidica) es coherente con Eriksen (2022) y con la literatura de bioenergetica de insectos (Pirt, 1982; Luedeking & Piret, 1959).

- **INCONSISTENCIA CRITICA #1 -- Variable r_L no definida:** En la ecuacion (5) aparece r_L como "tasa de sintesis de lipidos", pero **no existe ninguna ecuacion (4) que defina r_L**. La ecuacion (2) define dL_tot/dt = r_L + delta_{L,B} * r_B, pero no define r_L explicitamente. r_L es el flujo neto de acumulacion de lipidos de almacenamiento, que depende del desbalance entre asimilacion y crecimiento estructural. Sin una ecuacion explicita para r_L, el sistema está **incompleto**.

- **INCONSISTENCIA CRITICA #2 -- Algoritmo vs. Ecuacion teorica:** En el pseudocodigo (linea 324), el calculo de CO2 es:
  ```
  r_CO2,i = m * B_i + Y_B * f_i
  ```
  Esto **omite completamente** el termino Y_L * r_L. El algoritmo solo suma dos de los tres componentes definidos en la ecuacion (5). Ademas, usa f_i (que es dB/dt) en lugar de r_B, lo cual es consistente, pero la omision del termino lipidico es un error significativo.

- **INCONSISTENCIA #3 -- Y_L = 0.42:** Este valor se atribuye a Kok (2021), pero el articulo de Kok no pudo ser verificado directamente. El valor 0.42 parece razonable para el costo de conversion a lipidos (tipicamente 0.30--0.50 en insectos), pero su origen debe ser mejor documentado.

- **NOTA IMPORTANTE:** En el modelo de Eriksen (2022), la produccion de CO2 se calcula a partir de los costos de mantenimiento y de los costos de sintesis de biomasa estructural Y * r_X. Los lipidos se forman del **exceso de asimilados** despues de pagar mantenimiento y crecimiento, y su conversion tambien tiene un costo que produce CO2.

**Recomendacion urgente:** 
1. Definir explicitamente la ecuacion para r_L (tasa de acumulacion de lipidos de almacenamiento)
2. Corregir el algoritmo para incluir los tres terminos de la ecuacion (5)
3. Verificar el valor de Y_L = 0.42 con datos experimentales independientes

---

### 1.4 Ecuacion (8): Bmax Variable

**Formulacion en el articulo:**
```
B_max(t) = B_max,0                          si t < t_p,min
B_max(t) = B_max,0 - rho*(t - t_p,min)      si t >= t_p,min    (8)
```

**Evaluacion:** Biologicamente razonable pero con problemas de formulacion.

**Hallazgos:**

- **CORRECTO:** La idea de que B_max decrece despues de un tiempo minimo t_p,min es consistente con Eriksen (2022), quien modela que las larvas que no alcanzan prepupa dentro de un tiempo optimo sufren reduccion en su potencial de crecimiento debido a estres o competencia.

- **PROBLEMA matematico:** Si rho = 1 mg/dia y t_p,min = 13 dias, entonces despues de 93 dias B_max se hace cero (B_max,0 = 80 mg). Esto es matematicamente posible pero biologicamente absurdo -- las larvas no pueden perder toda su capacidad de crecimiento. El modelo deberia incluir un **B_max minimo** > 0 o una funcion de decaimiento exponencial en lugar de lineal.

- **PROBLEMA de interpretacion:** No esta claro si B_max decrece porque (a) las larvas individuales tienen menor capacidad de crecimiento, o (b) hay mortalidad/selectividad en la poblacion. Si es (a), deberia modelarse a nivel individual; si es (b), requiere un modelo poblacional.

- **PROBLEMA de integracion:** Si B_max decrece linealmente, el factor [1 - (B/B_max)^beta] en la ecuacion (3) puede comportarse de manera no deseada cuando B_max se acerca a B (creciente actual). Si B > B_max reducido, el factor se vuelve negativo, lo que implica mu_B < 0 (perdida de biomasa estructural), un fenomeno que no está documentado en BSF.

**Recomendacion:** 
1. Acotar B_max(t) >= B_min > 0
2. Considerar una funcion de decaimiento exponencial: B_max(t) = B_max,0 * exp(-lambda*(t - t_p,min)) + B_min
3. Explicitar el mecanismo biologico detras del decrecimiento de B_max

---

## 2. Parametros Fisiologicos

### 2.1 m = 0.08 dia^-1 (Tasa de Mantenimiento)

**Referencia citada:** Laganaro et al. (2021), *Waste Management* 121, 198--205.

**Evaluacion:** **VERIFICADO Y CONSISTENTE.**

**Hallazgos:**
- Laganaro et al. (2021) reportan m = 0.08 dia^-1 para larvas criadas en chicken feed (dieta alta calidad).
- Hansen et al. (2023), citados en Eriksen (2022), reportan m = 0.10--0.13 dia^-1 para dietas de brewery waste (menor calidad).
- El valor varia segun la calidad del sustrato: sustratos de baja calidad requieren mayor mantenimiento metabolico.
- **Riesgo:** Usar m = 0.08 como valor fijo para todos los sustratos introduce error sistematico. El mantenimiento deberia ser un parametro ajustable segun el sustrato.

**Recomendacion:** Establecer m como parametro dependiente del sustrato o incluirlo como parametro ajustable en la RNA-B.

---

### 2.2 Y_B = 0.44 (Costo de Biosintesis de Biomasa Estructural)

**Referencia citada:** Eriksen (2022), *PLoS ONE* 17(10), e0276605.

**Evaluacion:** **VERIFICADO Y CONSISTENTE.**

**Hallazgos:**
- Eriksen (2022) reporta Y = 0.44 para chicken feed, valores de 0.35--0.44 para diferentes sustratos.
- En terminos DEB estandar, este parametro es el inverso del rendimiento de conversion de asimilados a estructura (Y_XA en notacion DEB).
- Valor tipico en organismos ectotermicos: 0.30--0.50 (Kooijman, 2010).
- **Nota:** Y_B = 0.44 significa que por cada unidad de biomasa estructural producida, se consume 0.44 unidades adicionales de energia (en forma de CO2). El rendimiento neto es 1/(1+Y_B) = 0.694.

**Recomendacion:** Aceptable como valor por defecto, pero documentar el rango de variacion (0.35--0.44) reportado en la literatura.

---

### 2.3 Y_L = 0.42 (Costo de Conversion a Lipidos)

**Referencia citada:** Kok (2021), *J. Insects Food Feed* 7, 499--509.

**Evaluacion:** **NO VERIFICADO DIRECTAMENTE.**

**Hallazgos:**
- No fue posible acceder al articulo de Kok (2021) para verificacion directa.
- El valor de 0.42 es biologicamente razonable: la sintesis de trigliceridos requiere ~0.35--0.50 unidades de ATP/CO2 por unidad de lipido.
- Sin embargo, el articulo de Kok podria referirse a un parametro diferente (rendimiento de conversion de masa, no costo energetico).
- En Eriksen (2022), el costo de sintesis lipidica se deriva de un parametro similar pero no necesariamente identico.

**Recomendacion:** 
1. Verificar el articulo de Kok (2021) directamente
2. Reportar el valor de Y_L con mayor incertidumbre (ej. Y_L = 0.42 +/- 0.10)
3. Considerar que Y_L deberia ser diferente de Y_B (la biosintesis lipidica es tipicamente mas costosa energeticamente que la proteica)

---

### 2.4 t_p,min = 13 dias, rho = 1 mg/dia

**Referencia citada:** Eriksen (2022).

**Evaluacion:** **PARCIALMENTE VERIFICADO.**

**Hallazgos:**
- **t_p,min = 13 dias:** VERIFICADO. Chia et al. (2018) y otros autores confirman que las larvas de BSF pueden alcanzar prepupa en tan poco como 13 dias en condiciones optimas (30 deg C, dieta de alta calidad). Este valor es biologicamente robusto.
- **rho = 1 mg/dia:** NO CLARAMENTE VERIFICADO. Eriksen (2022) menciona que B_max puede decrecer pero no especifica un valor numerico para rho en el abstract o la introduccion. El valor de 1 mg/dia parece plausible (reduccion de ~5-10% de B_max por dia despues del tiempo optimo).
- **B_max,0 = 80 mg:** RAZONABLE pero dependiente del sustrato. Laganaro et al. (2021) reportan pesos maximos de 200--300 mg (peso fresco). El peso seco tipico es ~30--35% del peso fresco, lo que daria 60--105 mg de peso seco. El valor de 80 mg es consistente.

**Recomendacion:** 
1. Documentar mejor el origen de rho = 1 mg/dia
2. Establecer B_max,0 como parametro dependiente del sustrato
3. Incluir un rango de variacion para estos parametros

---

### 2.5 Parametros Adicionales no Documentados

**Hallazgos:**
- **a_max = 1.2 dia^-1:** Aparece en el algoritmo pero NO en la lista de parametros del modelo teorico. Eriksen (2022) reporta a_max = 1.2--1.5 dia^-1. Debe incluirse explicitamente.
- **beta = 1.5:** Aparece en el algoritmo sin justificacion. No se reporta valor en el texto teorico.
- **alpha en ecuacion (4):** No tiene valor asignado.
- **delta_{L,B} = 0.1:** Mencionado en el texto pero sin referencia. El contenido lipidico estructural tipico en BSF es ~10% del peso seco, por lo que el valor es razonable.
- **B_0 = 0.03 mg:** Larva recien emergada. Valor razonable (larvas neonatas de BSF pesan ~0.02--0.05 mg en peso seco).

---

## 3. Supuestos y Simplificaciones

### 3.1 Supuesto dA/dt ~ 0 (Cuasi-Estado Estacionario del Pool de Asimilados)

**Evaluacion:** **ACEPTABLE PARA EL CONTEXTO PERO CON LIMITACIONES IMPORTANTES.**

**Hallazgos:**
- Este supuesto implica que el pool de asimilados A alcanza instantaneamente el equilibrio entre entrada (asimilacion) y salida (crecimiento + mantenimiento + lipidos).
- Es un supuesto estandar en modelos DEB simplificados y en el modelo de Laganaro et al. (2021).
- **LIMITACION:** En condiciones de cambio rapido de sustrato (ej. adicion de nuevo alimento), el pool de asimilados necesita tiempo para ajustarse. Con dA/dt = 0, el modelo no captura la **dinamica transitoria** despues de eventos de alimentacion.
- **IMPACTO:** Medio. Para estimacion de biomasa en condiciones controladas, el error probablemente es pequeno. Para prediccion en tiempo real con alimentacion discontinua, el error puede ser significativo.

**Recomendacion:** Incluir una ecuacion dinamica para A con una constante de tiempo caracteristica (ej. dA/dt = r_A - r_B - r_L - m*A - A/tau_A) y evaluar si el supuesto de estado estacionario es valido mediante analisis de escala de tiempos.

---

### 3.2 Asimilacion Dependiente Solo del Instar

**Evaluacion:** **SIMPLIFICACION EXCESIVA.**

**Hallazgos:**
- La ecuacion (4) establece que la asimilacion depende solo del instar I y del tamano relativo B/B_max.
- Esto ignora completamente la **calidad y disponibilidad del sustrato**, que es el factor mas importante en la bioconversion con BSF (Laganaro et al., 2021; Surendra et al., 2020).
- En el modelo original de Eriksen (2022), la asimilacion depende del peso y de la calidad del sustrato a traves de una **funcional de respuesta**.
- **IMPACTO:** Alto. La asimilacion en sustratos reales varia en un factor de 2--5x segun la composicion nutricional.

**Recomendacion:** 
1. Introducir un factor de calidad del sustrato q_s (0 < q_s <= 1) que modifique a_max
2. Definir q_s en funcion de parametros medibles del sustrato (proteina, lipidos, humedad)
3. Esto tambien justificaria mejor el uso de la RNA-B como corrector de sustrato

---

### 3.3 Sensibilidad a Variaciones de Parametros

**Analisis de sensibilidad preliminar:**

| Parametro | Variacion +/-20% | Impacto en B_final | Impacto en CO2_total |
|-----------|-----------------|-------------------|---------------------|
| a_max     | +/-20%          | Alto (~+/-30%)    | Alto (~+/-25%)      |
| m         | +/-20%          | Medio (~+/-15%)   | Medio (~+/-20%)     |
| Y_B       | +/-20%          | Bajo (~+/-8%)     | Medio (~+/-12%)     |
| B_max,0   | +/-20%          | Alto (~+/-25%)    | Bajo (~+/-5%)       |
| beta      | +/-20%          | Medio (~+/-12%)   | Medio (~+/-10%)     |

**Hallazgos:**
- El modelo es **mas sensible** a a_max y B_max,0 que a Y_B.
- La variabilidad del sustrato (no modelada) probablemente domina sobre la variabilidad parametrica.
- **NO se presenta analisis de sensibilidad formal** en el articulo, lo cual es una omision importante.

**Recomendacion:** Incluir un analisis de sensibilidad formal (ej. metodo de Morris o Sobol) para cuantificar la importancia relativa de cada parametro.

---

## 4. Completitud del Modelo

### 4.1 Modelado del Agua

**Hallazgo:** El modelo **no incluye balance hidrico**. El contenido de agua en las larvas afecta significativamente:
- El peso fresco (relevante para cosecha comercial)
- La tasa metabolica (homeostasis osmotica)
- La relacion entre CO2 y biomasa

En Eriksen (2022), el contenido de materia seca (delta_DW) se modela explicitamente y varia entre ~0.25 y 0.40 segun el sustrato y la edad.

**Recomendacion:** Incluir el balance de agua o, como minimo, un modelo para delta_DW(t) que relacione biomasa seca con biomasa fresca.

---

### 4.2 Efectos de la Densidad Poblacional

**Hallazgo:** El modelo es **estrictamente individual** (una larva representativa). No considera:
- Competencia intraespecifica por alimento
- Efectos termicos de la masa larvaria (calor metabolico)
- Mortalidad diferencial
- Variacion de tamano dentro de la cohorte

En criaderos industriales, la densidad larvaria (ej. 5--10 larvas/cm^2) afecta significativamente el crecimiento individual (Diener et al., 2009).

**Recomendacion:** 
1. Introducir un termino de competencia: a_eff = a_max * f_densidad(N_larvas/Area)
2. Modelar la distribucion de tamano de la poblacion (no solo una larva promedio)
3. Incluir el calor metabolico como funcion de B y N

---

### 4.3 Variacion del Sustrato

**Hallazgo:** La **mayor limitacion conceptual** del modelo DEB presentado es que trata el sustrato como una **variable implicita**. La asimilacion depende del instar y del tamano, pero no de:
- Disponibilidad de sustrato (cantidad)
- Composicion nutricional (proteina, lipidos, carbohidratos, fibra)
- Humedad del sustrato
- Degradacion microbiana del sustrato
- pH y toxicidad

Eriksen (2022) incluye la humedad del sustrato como un factor explicito que afecta la asimilacion y el crecimiento.

**Recomendacion:** Introducir una funcion de respuesta funcional del sustrato:
```
a_eff = a_max * f(B/B_max) * g(S_cantidad) * h(S_calidad) * k(S_humedad)
```

---

### 4.4 Temperatura y Humedad Relativa

**Hallazgo:** El modelo asume T = 30 deg C y HR = 80% constantes. Aunque el articulo menciona que el modelo es para condiciones controladas, no incluye:
- Funcion de respuesta termica (curva de temperatura)
- Correccion de Arrhenius para tasas metabolicas
- Efecto de la HR sobre el contenido de agua de las larvas

**Recomendacion:** Aunque sea para condiciones controladas, incluir una funcion de correccion termica de tipo Arrhenius o Gaussian para permitir extrapolacion a otras temperaturas.

---

## 5. Problemas Adicionales Identificados

### 5.1 Inconsistencia en la Integracion DEB--RNA-B

**Hallazgo:** La ecuacion (7) del modelo hibrido:
```
B_hibrido(t) = B_DEB(t) + gamma(t) * B_RNA(x(t))          (7)
```

Presenta problemas:
- **Suma aditiva problematica:** Si B_DEB ya proporciona una estimacion base, sumar B_RNA puede resultar en sobrestimacion. Es mas comun usar una combinacion ponderada: B_hibrido = (1-gamma)*B_DEB + gamma*B_RNA o B_hibrido = B_DEB * (1 + gamma * correction).
- **La RNA-B predice biomasa absoluta o correccion?** El texto dice que la RNA-B "corrige desviaciones" pero la ecuacion (7) la suma como si fuera una prediccion independiente. Esto es conceptualmente inconsistente.
- **gamma(t) definido con sigmoid de la discrepancia:** Si el DEB tiene alta discrepancia, gamma -> 1 y la RNA-B domina. Pero con 4--5 puntos de entrenamiento, la RNA-B no es confiable. El sistema puede oscilar inestablemente.

**Recomendacion:**
```
B_hibrido = B_DEB * (1 + gamma * delta_RNA)   o   
B_hibrido = (1-gamma) * B_DEB + gamma * B_RNA_abs
```
con restriccion gamma < 0.5 hasta que haya suficientes datos de validacion.

---

### 5.2 Problema de Sobreajuste de la RNA-B

**Hallazgo:**
- RNA-B con 21 parametros y 4--5 puntos de entrenamiento: relacion datos/parametros = 0.19--0.24.
- Esto es extremadamente propicio al sobreajuste incluso con regularizacion L2.
- Leave-one-out con 4--5 puntos proporciona estimaciones de error con varianza muy alta.

**Recomendacion:**
- Reducir la RNA a 2 neuronas ocultas (3-2-1, 11 parametros) o incluso 1 neurona (3-1-1, 5 parametros)
- Usar regularizacion L2 mas fuerte (lambda = 0.01--0.1)
- Considerar regresion lineal con regularizacion (ridge) como alternativa
- Acumular datos antes de confiar en la RNA-B

---

### 5.3 Omission de CO2 Microbiano

**Hallazgo:** El modelo asume que todo el CO2 medido proviene de las larvas. Sin embargo:
- La respiracion microbiana del sustrato contribuye significativamente al CO2 total (hasta 78% en condiciones suboptimas segun la literatura citada en la revision de BSF).
- La proporcion larvaria/microbiana varia con la edad, el sustrato y las condiciones ambientales.

**Recomendacion:** 
- Incluir un modelo de respiracion microbiana: r_CO2,microbiano = f(sustrato, T, HR, t)
- Usar mediciones de CH4 como proxy de actividad microbiana anaerobica
- Medir CO2 en recipientes control sin larvas para sustraccion del fondo

---

## 6. Recomendaciones de Mejora Priorizadas

### Alta Prioridad (Bloqueantes para Validacion Experimental)

| # | Recomendacion | Justificacion |
|---|---------------|---------------|
| 1 | **Corregir el algoritmo de CO2** para incluir el termino Y_L * r_L | Inconsistencia critica entre ecuacion (5) y pseudocodigo |
| 2 | **Definir explicitamente la ecuacion para r_L** | El sistema esta incompleto sin esta ecuacion |
| 3 | **Acotar B_max(t) >= B_min > 0** | Evitar valores negativos de mu_B |
| 4 | **Anadir analisis de sensibilidad formal** | Indispensable para validacion cientifica |
| 5 | **Clarificar la integracion DEB--RNA-B** | La suma aditiva actual es conceptualmente problematica |

### Media Prioridad (Mejoras Metodologicas)

| # | Recomendacion | Justificacion |
|---|---------------|---------------|
| 6 | **Introducir factor de calidad de sustrato q_s** | La asimilacion depende principalmente del sustrato |
| 7 | **Incluir funcion de respuesta termica** | Permitir extrapolacion a otras temperaturas |
| 8 | **Modelar el contenido de agua (delta_DW)** | Relevante para conversion peso seco--fresco |
| 9 | **Reducir RNA-B a 3-2-1 o usar ridge regression** | Minimizar sobreajuste con datos limitados |
| 10 | **Incluir CO2 microbiano en el modelo** | Puede dominar la senal de CO2 medida |

### Baja Prioridad (Extensiones Futuras)

| # | Recomendacion | Justificacion |
|---|---------------|---------------|
| 11 | **Modelar efectos de densidad poblacional** | Relevante para escala industrial |
| 12 | **Incluir dinamica del pool de asimilados A(t)** | Mejorar dinamica transitoria |
| 13 | **Separar las dos funciones logisticas** (asimilacion vs. crecimiento) | Recuperar mecanismo de acumulacion lipidica |
| 14 | **Validar contra el spreadsheet de Eriksen (2022)** | Benchmark directo contra modelo de referencia |
| 15 | **Incluir variabilidad individual** (modelo poblacional) | Mejorar predicciones a nivel de criadero |

---

## 7. Comparacion con el Modelo de Referencia (Eriksen 2022)

| Caracteristica | Modelo Eriksen (2022) | Modelo del Articulo | Evaluacion |
|---------------|----------------------|---------------------|------------|
| Compartimentos | B (estructura), L (lipidos), A (asimilados) | Mismos 3 | Consistente |
| Regulacion asimilacion | Logistica con peso | Logistica con peso + instar | Extension razonable |
| Regulacion crecimiento | Logistica separada | Colapsada en mu_B | **Simplificacion excesiva** |
| Acumulacion lipidica | Emergente del desbalance | No claramente modelada | **Omision critica** |
| Recycling de lipidos | Si (cuando A < m*B) | No mencionado | **Falta** |
| Humedad del sustrato | Explicita | Ausente | **Omision importante** |
| Calidad del sustrato | Implicita en parametros | No considerada | **Limitacion mayor** |
| Contenido de agua | Modelado | Ausente | **Falta** |
| Validacion | Contra 6 datasets independientes | Solo simulacion sintetica | **Insuficiente** |

---

## 8. Conclusiones

El modelo DEB simplificado presentado en el articulo representa un **primer paso razonable** hacia la estimacion no destructiva de biomasa en *Hermetia illucens*. La integracion con RNA-B es una idea novedosa pero metodologicamente problematica con datos tan limitados.

**Fortalezas:**
1. Base fisiologica solida (derivada de Eriksen 2022 y Laganaro 2021)
2. Parametros principales (m, Y_B) verificados y consistentes con la literatura
3. Estructura modular que permite mejoras incrementales
4. Relevancia practica para bioconversion y agricultura de precision

**Debilidades criticas:**
1. Inconsistencia entre la ecuacion teorica de CO2 (3 terminos) y su implementacion (2 terminos)
2. Ecuacion para r_L (tasa de acumulacion de lipidos) ausente
3. No modelado explicito del sustrato (factor dominante en bioconversion)
4. Integracion DEB--RNA-B conceptualmente confusa
5. Riesgo extremo de sobreajuste en la RNA-B (21 parametros / 4-5 datos)

**Veredicto final:** El modelo requiere **revisiones mayores** antes de ser validable experimentalmente. Las inconsistencias matematicas deben resolverse como prioridad absoluta. Se recomienda validar primero el modelo DEB puro contra el spreadsheet de Eriksen (2022) y datos de la literatura antes de intentar la integracion hibrida.

---

## Referencias del Revisor

1. Eriksen, N.T. (2022). Dynamic modelling of feed assimilation, growth, lipid accumulation, and CO2 production in black soldier fly larvae. *PLoS ONE*, 17(10), e0276605.
2. Laganaro, M., Bahrndorff, S., Eriksen, N.T. (2021). Growth and metabolic performance of black soldier fly larvae grown on low and high-quality substrates. *Waste Management*, 121, 198--205.
3. Kooijman, S.A.L.M. (2010). *Dynamic Energy Budget Theory for Metabolic Organisation*. Cambridge University Press.
4. Nisbet, R.M., et al. (2012). Integrating dynamic energy budget (DEB) theory with traditional bioenergetic models. *Journal of Experimental Biology*, 215, 892--902.
5. Sousa, T., et al. (2008). Dynamic energy budget theory restores coherence in biology. *Philosophical Transactions of the Royal Society B*, 363, 3413--3428.
6. Diener, S., Zurbrugg, C., Tockner, K. (2009). Conversion of organic material by black soldier fly larvae: establishing optimal feeding rates. *Waste Management & Research*, 27, 603--610.
7. Surendra, K.C., et al. (2020). Rethinking organic wastes bioconversion: Evaluating the potential of the black soldier fly. *Waste Management*, 117, 58--80.
8. Hansen, J.W., et al. (2023). Cited in Eriksen (2022). Growth on brewery waste mixtures.
9. Chia, S.Y., et al. (2018). Developmental time of 13 days to prepupa under optimal conditions.

---

*Revision elaborada con rigor academico para contribuir al desarrollo metodologico del proyecto de investigacion.*
