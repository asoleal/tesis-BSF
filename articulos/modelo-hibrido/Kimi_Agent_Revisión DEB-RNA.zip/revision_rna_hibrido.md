# Revision Cientifica: Modelo Hibrido DEB-RNA para Estimacion de Biomasa en *Hermetia illucens*

**Revisor:** Experto en ML aplicado a sistemas biologicos y modelado hibrido mecanicista-ML
**Fecha:** Revision realizada sobre manuscrito `estructura_hibrida_deb_rna.tex`
**Clasificacion:** REVISION CON HALLAZGOS CRITICOS

---

## Resumen Ejecutivo

El manuscrito presenta un modelo hibrido DEB-RNA-B para estimar biomasa de *H. illucens* a partir de CO2 respiratorio. La propuesta tiene meritos conceptuales importantes (integracion mecanicista-ML, arquitectura minimalista por necesidad de datos). Sin embargo, el analisis riguroso revela **tres hallazgos criticos** que deben resolverse antes de la implementacion experimental:

1. **CRITICO [HC-1]**: El peso de confianza adaptativo gamma(t) tiene un bug matematico: gamma(0) = 0.5 en lugar de gamma(0) = 0, lo que significa que la RNA interviene con 50% de peso INCLUSO cuando el DEB predice perfectamente.
2. **CRITICO [HC-2]**: La arquitectura 3-4-1 (21 parametros) con solo 4-5 puntos de entrenamiento representa un deficit severo de datos (ratio p/n = 5.2), haciendo el entrenamiento directo estadisticamente no viable sin regularizacion extrema o pre-entrenamiento.
3. **CRITICO [HC-3]**: Las tres features de entrada estan mecanicamente acopladas (Delta_C es la derivada de Acum), generando colinealidad severa que reduce el rango efectivo de la matriz de entrada a 1-2 dimensiones, no 3.

Se identifican adicionalmente 8 hallazgos mayores y 10 recomendaciones concretas de mejora.

---

## 1. Arquitectura RNA-B (3-4-1)

### 1.1 Veredicto General: CONDICIONALMENTE ACEPTABLE con modificaciones criticas

La eleccion de una arquitectura minimalista (3-4-1) es correcta dado el contexto de datos extremadamente limitados. Sin embargo, presenta problemas fundamentales.

### 1.2 Analisis de Capacidad Expresiva

**Capacidad teorica:** Con 4 neuronas ReLU en 3D, la red puede representar hasta sum(C(4,i) for i=0..3) = 15 regiones lineales. En la practica, con 4 neuronas hay 4 "plantillas" de correccion disponibles.

**Evaluacion:** Para un problema de correccion de desviaciones DEB (que se espera sean suaves y monotonicas), 4 grados de libertad es razonable. No se necesita mayor complejidad.

### 1.3 Ratio Parametros/Datos - HALLAZGO CRITICO [HC-2]

| Escenario | Datos disponibles | Parametros | Ratio p/n | Evaluacion |
|-----------|------------------|------------|-----------|------------|
| Reales (n=4) | 4 puntos | 21 | **5.25** | CRITICO: sobreajuste inevitable |
| Reales (n=5) | 5 puntos | 21 | **4.20** | CRITICO: sobreajuste inevitable |
| Sinteticos (n=20) | 20 puntos | 21 | **1.05** | CRITICO: n ~ p, varianza alta |
| Minimo recomendado (5x) | 105 puntos | 21 | 0.20 | Aceptable |

**Recomendacion-1:** Con 4-5 puntos reales, el entrenamiento directo de 21 parametros es estadisticamente no factible. Se requiere una de estas alternativas:
- **(a)** Reducir a arquitectura 3-2-1 (11 parametros) para datos reales
- **(b)** Usar regularizacion L2 con lambda >= 10 (no 0.001) - ver seccion 1.5
- **(c)** Pre-entrenar con simulaciones y hacer fine-tuning con 4-5 puntos
- **(d)** Usar Bayesian Neural Network con priors informativos

### 1.4 Numero de Neuronas Ocultas

**Pregunta: Son suficientes 4 neuronas?**

Si, para el proposito de correccion residual. El DEB captura la fisica base (crecimiento logistico), y la RNA solo necesita corregir desviaciones sustrato-especificas. Con datos tan limitados, mas neuronas empeorarian el sobreajuste.

**Sin embargo**, con la colinealidad de features (seccion 2), el rango efectivo es menor. Se sugiere:
- **Recomendacion-2:** Reducir a 2-3 neuronas ocultas si solo se usan las features propuestas, o
- **Recomendacion-3:** Agregar features no colineales (dC/dt, varianza) para aprovechar las 4 neuronas.

### 1.5 Regularizacion L2 - HALLAZGO MAYOR [HM-1]

El valor propuesto lambda = 10^-3 es **insuficiente por 3-4 ordenes de magnitud**.

**Analisis cuantitativo:**
- Penalizacion L2 esperada: lambda * ||w||^2 ~ 0.001 * 21 = 0.021 (con pesos O(1))
- MSE tipico con biomasa de 100-200 mg: ~22,500
- Ratio L2/MSE ~ 10^-6: la regularizacion tiene efecto despreciable

**Para datos reales (n=4), se necesita lambda tal que el problema sea bien condicionado.** Esto tipicamente requiere lambda en el rango [0.1, 10].

**Recomendacion-4:** Aumentar lambda a 1.0 o superior para datos reales, o usar regularizacion L1 (lasso) para seleccion automatica de features. Implementar validacion cruzada para seleccionar lambda.

### 1.6 Validacion Leave-One-Out (LOO)

LOO es la unica opcion viable con 4-5 puntos. Sin embargo:

- Con n=4, LOO entrena con 3 puntos y 21 parametros (ratio 7) - **el sistema es indeterminado**
- LOO con n<p tiene varianza muy alta en la estimacion del error de generalizacion
- No provee intervalos de confianza

**Recomendacion-5:** Complementar LOO con:
- Bootstrap de residuos para intervalos de confianza
- Analisis de sensibilidad a perturbaciones en los parametros DEB
- Validacion Bayesiana con distribuciones a posteriori

---

## 2. Features de Entrada

### 2.1 Veredicto General: NECESITA REDISENO

### 2.2 Feature 1: Delta_C(t) = C(t) - C_0

| Atributo | Evaluacion |
|----------|------------|
| Computabilidad en tiempo real | SI - O(1) |
| Informacion relevante | SI - refleja acumulacion de CO2 |
| Escalamiento | [0, 4600] ppm - necesita normalizacion |
| Problema | Altamente correlacionado con Acum |

### 2.3 Feature 2: tau_50% (tiempo a 50% saturacion) - HALLAZGO MAYOR [HM-2]

**Esta feature NO es causal y NO es computable en tiempo real.**

Problemas:
1. Requiere detectar el punto de 50% de saturacion, que puede ocurrir en t > t_actual
2. No esta disponible hasta que el proceso avanza significativamente
3. Es un estadistico de toda la trayectoria, no una medida local

**Recomendacion-6:** Reemplazar tau_50% por features locales computables en tiempo real:
- dC/dt: tasa instantanea de CO2 (proxy metabolico directo)
- C(t)/C_max: fraccion de saturacion actual (normalizada)
- Varianza en ventana deslizante: estabilidad del proceso

### 2.4 Feature 3: Acum = integral[C(tau)-C_0]dtau

| Atributo | Evaluacion |
|----------|------------|
| Computabilidad | SI - integracion acumulativa O(N) |
| Informacion | SI - proxy de biomasa metabolica total |
| Problema | Crece monotonicamente sin cota; es la integral de Delta_C |

### 2.5 Colinealidad Severa - HALLAZGO CRITICO [HC-3]

**Relacion mecanica:** Acum(t) = integral_0^t Delta_C(tau) dtau

Esto implica que Delta_C(t) = d/dt[Acum(t)] - son operaciones inversas. Matematicamente, la matriz de diseno tiene rango efectivo ~ 1.5-2, no 3.

**Consecuencia:** La RNA recibe informacion redundante, los pesos no estan identificados, y el sistema es mal condicionado.

**Recomendacion-7:** Redisenar el vector de features para eliminar colinealidad:

| Feature | Tipo | Computabilidad | Independencia |
|---------|------|----------------|---------------|
| dC/dt (tasa) | Local | Tiempo real | Alta - informacion dinamica |
| C(t)/C_max | Local | Tiempo real | Media - normalizacion |
| Acum(t) / (t * C_max) | Acumulada | Tiempo real | Media - crecimiento normalizado |
| Varianza(dC/dt) | Estadistica | Ventana | Alta - ruido/salud del sistema |
| t/t_total | Temporal | Tiempo real | Alta - fase del proceso |

### 2.6 Features Faltantes

Se identifican features adicionales que mejorarian la prediccion:

1. **dC/dt**: La tasa de produccion de CO2 es el proxy metabolico mas directo
2. **t/t_total**: Normalizacion temporal (fase del proceso)
3. **Varianza de C en ventana**: Indica estabilidad/estres del sistema
4. **(1/C)(dC/dt)**: Tasa especifica de crecimiento (adimensional)
5. **Temperatura del sustrato**: Si difiere de T_ambiente
6. **Humedad del sustrato**: Afecta metabolismo larvario

---

## 3. Integracion Hibrida DEB-RNA

### 3.1 Veredicto General: CONCEPTO SOLIDO, IMPLEMENTACION DEFICIENTE

### 3.2 Ecuacion (9) de Prediccion Combinada - HALLAZGO CRITICO [HC-1]

La ecuacion propuesta es:

```
B_hibrido(t) = B_DEB(t) + gamma(t) * B_RNA(x(t))
```

**Problema fundamental:** Cuando gamma(t) -> 1, B_hibrido = B_DEB + B_RNA.
Si B_RNA es del orden de B_DEB (correccion del 100%), entonces B_hibrido ~ 2 * B_DEB.

**Esto no es una interpolacion, es una suma aditiva no acotada.**

**Formas correctas alternativas:**

| Forma | Ecuacion | Cuando gamma=0 | Cuando gamma=1 | Interpretacion |
|-------|----------|----------------|----------------|----------------|
| **Suma (propuesta)** | B_DEB + gamma*B_RNA | B_DEB | B_DEB + B_RNA | Correccion aditiva |
| **Correccion** | B_DEB + gamma*(B_RNA - B_DEB) | B_DEB | B_RNA | Interpolacion a B_RNA |
| **Mezcla** | (1-gamma)*B_DEB + gamma*B_RNA | B_DEB | B_RNA | Interpolacion convexa |
| **Multiplicativa** | B_DEB * (1 + gamma*(B_RNA/B_DEB - 1)) | B_DEB | B_RNA | Correccion relativa |

**Recomendacion-8:** Cambiar a la forma de mezcla convexa:

```
B_hibrido(t) = (1 - gamma(t)) * B_DEB(t) + gamma(t) * B_RNA(x(t))
```

Esta garantiza:
- Acotacion: min(B_DEB, B_RNA) <= B_hibrido <= max(B_DEB, B_RNA)
- Interpretabilidad: gamma es literalmente el peso de la RNA
- gamma=0 -> puro DEB; gamma=1 -> puro RNA

### 3.3 Peso de Confianza gamma(t) - HALLAZGO CRITICO [HC-1 continuacion]

La funcion propuesta: gamma(t) = sigmoid(kappa * |dCO2|) con kappa = 0.1 ppm^-1

**Bug matematico identificado:**

| |dCO2| (ppm) | gamma_original | Deberia ser |
|-------------|----------------|-------------|
| 0 (DEB perfecto) | **0.500** | **0.000** |
| 10 | 0.731 | ~0.10 |
| 20 | 0.881 | ~0.50 |
| 50 | 0.993 | ~0.95 |

**Cuando el DEB predice perfectamente (dCO2 = 0), la RNA tiene 50% de peso.** Esto es incorrecto por diseno.

**Causa:** La funcion sigmoid(0) = 0.5. Sin bias negativo, el punto de 50% activacion esta en dCO2 = 0.

**Recomendacion-9:** Corregir gamma(t) de una de estas formas:

**Opcion A (recomendada):** Sigmoide con bias
```
gamma(t) = sigmoid(kappa * |dCO2| - alpha) con alpha = 5
```
Resultado: gamma(0) ~ 0.007, gamma(50) = 0.5, gamma(100) ~ 0.993

**Opcion B:** Tanh cuadrado
```
gamma(t) = tanh(kappa * |dCO2|)^2
```
Resultado: gamma(0) = 0 (correcto), crecimiento cuadratico inicial

**Opcion C:** Funcion escalon suavizada
```
gamma(t) = max(0, 1 - exp(-kappa * |dCO2|^2))
```
Resultado: gamma(0) = 0, crecimiento mas rapido que lineal

### 3.4 Valor de kappa = 0.1 ppm^-1

**Evaluacion:** El valor es agresivo - a 30 ppm de discrepancia ya se da gamma ~ 0.88.

**Problema:** El DEB tiene incertidumbre inherente de 10-50 ppm tipicamente (debido a variabilidad biologica, parametros no calibrados, simplificaciones del modelo). Con kappa=0.1, la RNA tomaria control en la mayoria de situaciones practicas.

**Recomendacion-10:** kappa debe calibrarse con datos reales. Valor sugerido inicial: 0.02 ppm^-1, que da:
- gamma(10 ppm) ~ 0.12 (DEB domina)
- gamma(50 ppm) ~ 0.73 (transicion)
- gamma(100 ppm) ~ 0.98 (RNA domina)

### 3.5 Riesgo de Inestabilidad

**Cuando gamma -> 1:** La prediccion depende casi exclusivamente de la RNA-B, que esta entrenada con 4-5 puntos. Esto es inherentemente inestable.

**Mitigacion necesaria:**
- Acotar gamma_max < 1 (ej: 0.9) para siempre mantener algo de DEB
- Activar alerta cuando gamma > 0.8 por mas de N ciclos consecutivos
- Revertir a DEB puro si la RNA predice valores fisicamente imposibles

---

## 4. Protocolo de Entrenamiento

### 4.1 Veredicto General: INADECUADO para el proposito

### 4.2 Datos Sinteticos

**Problemas identificados:**

1. **Muestreo insuficiente:** 5 curvas para cubrir un espacio 2D (a_max, beta) es extremadamente esparso. Se necesitan al menos 25 curvas para una cuadricula 5x5 razonable.

2. **Parametros no muestreados:** Solo varian a_max y beta. Parametros criticos como m (mantenimiento), Y_B (costo biosintesis), B_max no se varian sistematicamente.

3. **Ruido optimista:** sigma = 2 mg es 15-20 veces menor que la variabilidad biologica real esperada (CV ~ 25-30%, sigma ~ 30-40 mg para biomasa de 150 mg).

### 4.3 Hiperparametros

| Parametro | Valor propuesto | Evaluacion | Recomendacion |
|-----------|----------------|------------|---------------|
| Optimizador | Adam | APROPIADO | Mantener |
| lr = 10^-3 | 0.001 | APROPIADO | Mantener, o reducir a 5e-4 |
| MSE | MSE | APROPIADO | OK para sinteticos |
| Huber (reales) | Huber | EXCELENTE | Delta=1.0 para robustez |
| L2 lambda | 10^-3 | INSUFICIENTE | 1.0 a 10.0 para reales |
| Epocas max | 1000 | SUFICIENTE | OK |
| Parada temprana | paciencia=50 | EXCESIVA | Reducir a 10-20 |

### 4.4 Parada Temprana

Con 21 parametros y datos limitados, la red converge rapido pero puede sobreajustar. Paciencia=50 permite demasiadas epocas sin mejora antes de detener.

---

## 5. Métricas y Validacion

### 5.1 Veredicto General: INCOMPLETO

### 5.2 Métricas Propuestas

| Metrica | Evaluacion | Recomendacion |
|---------|-----------|---------------|
| AME (mg) | APROPIADA | Mantener |
| RMSE (mg) | REDUNDANTE con AME | Eliminar o complementar |
| R^2 | PROBLEMATICA con n=4-5 | Interpretar con precaucion |
| AME_CO2 | INCOMPLETA | Descomponer por fase |

### 5.3 Métricas Adicionales Necesarias

1. **MAPE (%):** Normaliza por magnitud, permite comparacion entre condiciones
2. **Intervalos de confianza:** Bootstrap o Bayesiano - ESENCIAL con n=4-5
3. **Indice de Theil (U):** Descompone error en sesgo + varianza + covarianza
4. **CV de prediccion:** Deberia ser < 20% para utilidad practica

### 5.4 Escenarios de Validacion

| Escenario | Evaluacion | Problema |
|-----------|-----------|----------|
| A (Simulacion) | DEBIL | Validacion circular: mismo modelo genera y valida |
| B (Laboratorio) | APROPIADO | Caso real, pero LOO con n=4 tiene varianza alta |
| C (Industrial) | **NO OPERATIVO** | Sin biomasa medida, la RNA no puede entrenarse |

### 5.5 Escenarios Faltantes

1. **Transferencia entre sustratos:** Generalizacion real
2. **Validacion temporal:** Predictividad en linea
3. **Validacion con perturbaciones:** Robustez
4. **Validacion Bayesiana:** Intervalos de credibilidad

---

## 6. Limitaciones y Mejoras

### 6.1 Limitaciones Identificadas

| ID | Limitacion | Severidad |
|----|-----------|-----------|
| HC-1 | gamma(0) = 0.5 (bug en peso de confianza) | CRITICA |
| HC-2 | Ratio p/n = 5.2 (sobreajuste inevitable) | CRITICA |
| HC-3 | Colinealidad severa entre features | CRITICA |
| HM-1 | Regularizacion L2 insuficiente (3 ordenes) | MAYOR |
| HM-2 | tau_50% no es computable en tiempo real | MAYOR |
| HM-3 | Ecuacion (9) es suma no acotada | MAYOR |
| HM-4 | Ruido sintetico 20x menor que real | MAYOR |
| HM-5 | Escenario C no operativo sin ground truth | MAYOR |
| hm-6 | Solo 2 parametros variados en sinteticos | MENOR |
| hm-7 | Validacion LOO con n<p | MENOR |

### 6.2 Recomendaciones Priorizadas

| Prioridad | Recomendacion | Impacto esperado |
|-----------|--------------|-----------------|
| **P0** | Corregir gamma(t) con bias (alpha=5) o usar tanh^2 | Elimina error del 50% en predicciones |
| **P0** | Cambiar ecuacion (9) a mezcla convexa | Garantiza acotacion e interpretabilidad |
| **P0** | Eliminar colinealidad en features | Mejora condicionamiento 10x |
| **P1** | Aumentar lambda a 1.0+ para datos reales | Controla sobreajuste |
| **P1** | Aumentar ruido sintetico a sigma=30-40 mg | Simulaciones mas realistas |
| **P1** | Reemplazar tau_50% por dC/dt y varianza | Features causales y computables |
| **P2** | Agregar metricas: MAPE, IC bootstrap, Theil U | Mejor evaluacion |
| **P2** | Escenario C: protocolo de transfer learning | Operatividad industrial |

### 6.3 Propuesta de Arquitectura Revisada

**Features de entrada (recomendadas):**
```
x = [dC/dt, C(t)/C_max, Acum/(t*C_max), var(dC/dt), t/t_total]
```

**Arquitectura RNA-B (revisada):**
- 5 entradas -> 3 neuronas ocultas (ReLU) -> 1 salida lineal
- Parametros: 5*3 + 3 + 3 + 1 = 22 (similar, pero features mejores)
- Entrenamiento: Pre-entrenar con 100+ curvas sinteticas, fine-tuning con 4-5 puntos reales

**Mecanismo hibrido (corregido):**
```
gamma(t) = sigmoid(kappa * |dCO2| - alpha)    # con alpha=5, kappa=0.02
B_hibrido(t) = (1 - gamma(t)) * B_DEB(t) + gamma(t) * B_RNA(x(t))
```

**Regularizacion:**
- Pre-entrenamiento sintetico: lambda = 10^-3 (debil)
- Fine-tuning real: lambda = 1.0 a 10.0 (fuerte, seleccionado por CV)

---

## 7. Conclusion del Revisor

El modelo hibrido DEB-RNA representa una direccion de investigacion valiosa con potencial para resolver un problema practico importante. El uso de DEB como base mecanicista es fisicamente informado y la arquitectura minimalista de la RNA es apropiada para el contexto de datos limitados.

Sin embargo, **tres hallazgos criticos impiden la implementacion en su forma actual**:

1. El bug en gamma(t) (gamma(0)=0.5) produce errores sistematicos del ~50% incluso cuando el DEB es perfecto.
2. La colinealidad entre features reduce drasticamente la capacidad efectiva del modelo.
3. El ratio parametros/datos hace el entrenamiento directo estadisticamente inviable.

Con las recomendaciones propuestas (especialmente P0), el marco puede convertirse en una herramienta util para la estimacion de biomasa en BSF.

**Calificacion global: REQUIERE REVISION MAYOR antes de implementacion experimental.**

---

*Figuras de soporte disponibles en: /mnt/agents/output/figuras_revision_hibrido.png*
